from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from datetime import datetime
import os
import pickle
# Create your views here.
def index(request):
    template = loader.get_template('Visu/index.html')
    context = {"date":datetime.today()}
    return HttpResponse(template.render(context,request))
"""
def predict(request):
    template = loader.get_template('Visu/predict.html')
    context = {"date":datetime.today()}
    return HttpResponse(template.render(context,request))
"""

def predict(request):
    if request.method == 'POST':
        
        gender = int(request.POST['gender'])  
        neuroticism = float(request.POST['neuroticism'])
        extraversion = float(request.POST['extraversion'])
        openness = float(request.POST['openness'])
        agreeableness = float(request.POST['agreeableness'])
        conscientiousness = float(request.POST['conscientiousness'])
        impulsiveness = float(request.POST['impulsiveness'])
        sensation = float(request.POST['sensation'])
        
        education = int(request.POST['education'])
        temp_educ = [0 for i in range(0,9)]
        temp_educ[education]=1
        
        age = int(request.POST['age'])
        temp_age = [0 for i in range(0,6)]
        temp_age[age]=1
        
        d = os.getcwd() #chemin du projet
        filename1 = d+'/Visu/static/model/model.sav'
        
        e = os.getcwd() #chemin du projet
        filename2 = e+'/Visu/static/model/model1.sav'
        
        f = os.getcwd() #chemin du projet
        filename3 = f+'/Visu/static/model/model2.sav'

        loaded_model1 = pickle.load(open(filename1, 'rb'))
        loaded_model2 = pickle.load(open(filename2, 'rb'))
        loaded_model3 = pickle.load(open(filename3, 'rb'))
        
        predicts=[gender,neuroticism,extraversion,openness,agreeableness,conscientiousness,impulsiveness,sensation]
        predicts=predicts+temp_educ+temp_age
        # Prediction sur le Test set
        y_pred1 = loaded_model1.predict([predicts])
        y_pred2 = loaded_model2.predict([predicts])
        y_pred3 = loaded_model3.predict([predicts])
        
        if (y_pred1==0):
            y_pred1="Non-user : Great you will not consume Heroin drugs"
        else:
            y_pred1="User : Becareful you will consume Heroin drugs !"
            
        if (y_pred2==0):
            y_pred2="Non-user : Great you will not consume Ecstasy drugs"
        else:
            y_pred2="User : Becareful you will consume Ecstasy drugs !"
            
        if (y_pred3==0):
            y_pred3="Non-user : Great you will not consume Benzo drugs"
        else:
            y_pred3="User : Becareful you will consume Benzo drugs !"
        
        context = {"y_pred1": y_pred1,"y_pred2":y_pred2,"y_pred3":y_pred3}
        return render(request, "Visu/predict.html", context)
